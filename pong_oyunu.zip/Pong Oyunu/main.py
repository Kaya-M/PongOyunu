# PyGame'i import etmek için
import pygame

pygame.init()

# Pencere Ayarları
pencere = pygame.display.set_mode((1000, 750))

pygame.display.set_caption('Pong Oyunu')

# Müzik
from pygame import *

mixer.init()
mixer.music.load('muzik.mp3')
mixer.music.play()
pygame.mixer.music.set_volume(0.35)

# Renkler
siyah = (0, 0, 0)
gri = (169, 169, 169)

# Sprite Sınıfları
class Top(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([10, 10])
        self.image.fill(siyah)
        self.rect = self.image.get_rect()
        self.speed = 14
        self.dx = 1
        self.dy = 1


class Raket1(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([10, 125])
        self.image.fill(siyah)
        self.rect = self.image.get_rect()
        self.points = 0


class Raket2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([10, 125])
        self.image.fill(siyah)
        self.rect = self.image.get_rect()
        self.points = 0


# Sprite Yaratımı
pong = Top()
pong.rect.x = 500
pong.rect.y = 375

raket1 = Raket1()
raket1.rect.x = 25
raket1.rect.y = 25

raket2 = Raket2()
raket2.rect.x = 965
raket2.rect.y = 225

raket_hizi = 14

# Sprite Grupları
butun_spritelar = pygame.sprite.Group()
butun_spritelar.add(raket1, raket2, pong)


# Ekran yenileme fonksiyonu
def redraw():
    # Arkaplanı griye boyar
    pencere.fill(gri)

    # Başlık yazısı
    font = pygame.font.SysFont('Algerian', 65)
    yazi = font.render('P O N G', False, siyah)
    yaziRect = yazi.get_rect()
    yaziRect.center = (1000 // 2, 375)
    pencere.blit(yazi, yaziRect)

    # Oyuncu 1 Skoru
    birincioyuncu_skor = font.render(str(raket1.points), False, siyah)
    o1Rect = birincioyuncu_skor.get_rect()
    o1Rect.center = (120, 375)
    pencere.blit(birincioyuncu_skor, o1Rect)

    # Oyuncu 2 Skoru
    ikincioyuncu_skor = font.render(str(raket2.points), False, siyah)
    o2Rect = ikincioyuncu_skor.get_rect()
    o2Rect.center = (880, 375)
    pencere.blit(ikincioyuncu_skor, o2Rect)

    # Bütün Sprite'ları günceller
    butun_spritelar.draw(pencere)

    # Ekrandaki cisimleri günceller
    pygame.display.update()


run = True

# Main Loop
while run:

    pygame.time.delay(35)

    # Oyundan Çıkış
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Topun hareketi
    pong.rect.x += pong.speed * pong.dx
    pong.rect.y += pong.speed * pong.dy

    # Raket Hareketi
    key = pygame.key.get_pressed()
    if key[pygame.K_w]:
        raket1.rect.y += -raket_hizi
    if key[pygame.K_s]:
        raket1.rect.y += raket_hizi
    if key[pygame.K_UP]:
        raket2.rect.y += -raket_hizi
    if key[pygame.K_DOWN]:
        raket2.rect.y += raket_hizi

    # Duvar ve Raketten topun sekmesi
    if pong.rect.y > 735:
        pong.dy = -1

    if pong.rect.y < 1:
        pong.dy = 1

    if pong.rect.x > 965:
        pong.rect.x, pong.rect.y = 500, 375
        pong.dx = -1
        raket1.points += 1

    if pong.rect.x < 1:
        pong.rect.x, pong.rect.y = 500, 375
        pong.dx = 1
        raket2.points += 1

    if raket1.rect.colliderect(pong.rect):
        pong.dx = 1

    if raket2.rect.colliderect(pong.rect):
        pong.dx = -1

    # Redraw fonksiyonunu tekrar çalıştırır
    redraw()

pygame.quit()
